#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>

int find_peaks (double* DA, int num_pts, int* peak_start, int* peak_end, int *flag, double energy_thresh){
    double max = 0;
    double min = 1E50;
    double avg = 0;
    int i, k;
    int peak = 0;
    double sum = 0;
    int seek_val = 1;
    int flag_size;
    int j = 0;
    int start = 0;
    int thresh = 10;
    int *flag1;
    
    flag_size = num_pts;
    
    flag1 = (int*) malloc (flag_size * sizeof (int));
    
    for (i = 0; i < num_pts; i++){
        if (DA[i] > max) max = DA[i];
        if (DA [i] < min) min = DA[i];
        avg += DA[i];
    }
    fprintf (stderr, "MAX = %lf\n", max);
    fprintf (stderr, "MIN = %lf\n", min);
    
    avg /= num_pts;
    
    for (i = 0; i < num_pts; i++){
        if (DA[i] >= energy_thresh*max) flag[i] = 1;
        else flag[i] = 0;
        if (i < 10) flag[i] = 0; //get rid of noise at the beginning of the recording
    }
    
    fprintf (stderr, "before filter\n");
    for (i = 0; i < num_pts; i++){
        fprintf (stderr, "%d", flag[i]);
    }
    fprintf (stderr, "\n\n");
    
    for (i = 1; i < num_pts - 1; i++){
        if (flag[i] == 1 && flag [i-1] == 0 && flag [i+1] == 0) flag [i] = 0;
        else if (flag [i] == 0 && flag [i-1] == 1 && flag [i+1] == 1) flag [i] = 1;
    }
    
    //gets rid of runs of 1s of size less than thresh
    j = 0;
    for (i = 0; i < num_pts; i++){
        if (flag [i] == 1){
            if (j == 0){
                start = i;
            }
            j++;
        }
        else if (flag [i] == 0 && j!= 0 && j < thresh){
            for (k = start; k <= i; k++){
                flag [k] = 0;
            }
            j = 0;
        }
        else j = 0;
    }
    
    for (i = 0; i < num_pts; i++){
        flag1[i] = flag[i];
    }
    
    int run_extend = 15;
    for (i = run_extend; i < num_pts - run_extend; i++){
        if (flag[i] == 0){
            for (j = 0; j < run_extend; j++){
                if (flag1 [i + j] == 1 || flag1 [i-j] == 1) flag [i] = 1;
            }
        }
    }
    
    fprintf (stderr, "after filter\n");
    for (i = 0; i < num_pts; i++){
        fprintf (stderr, "%d", flag[i]);
    }
    fprintf (stderr, "\n");
    
    i = 0;
    while (i < num_pts){
        while (flag [i] != seek_val){
            i++;
            if (i >= num_pts) break;
            j++;
        }
        if (i >= num_pts) break;
        
        if (seek_val == 1){
            peak_start [peak] = i;
            seek_val = 0;
            j = 0;
        }
        else {
            peak_end [peak] = i;
            peak ++;
            seek_val = 1;
            fprintf (stderr, "run_length = %d\n", j);
            j = 0;
        }
        
    }
    
    fprintf (stderr, "\n%d peaks\n", peak);
    for (i = 0; i < peak; i++){
        fprintf (stderr, "start = %d  end = %d\n", peak_start[i], peak_end[i]);
    }

    
    for (i = 0; i < peak; i++){
        fprintf (stderr, "start = %d  end = %d  width = %d\n", peak_start[i], peak_end[i], peak_end[i] - peak_start[i]);
    }
    
    fprintf (stderr, "++++++ ending find_peaks\n"); fflush (stderr);
    free (flag1);
    
    return peak;
    
    
}
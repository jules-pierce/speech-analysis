#!/usr/bin/env python
import os
import sys

if len(sys.argv) != 3 :
    print "usage is: " + sys.argv[0] + " file.wav crop_flag"
    sys.exit(0)

a = sys.argv[1].split (".")

os.system ("sox " + sys.argv[1] + " " + a[0] + ".raw")

if int (sys.argv[2]) != -1 :
    os.system ("./spectrum_img_new 8000 " + a[0] + ".raw " + a[0] + "_" + sys.argv[2] + ".bmp " + a[0] + "_" + sys.argv[2] + ".txt " + sys.argv[2])

else :
    os.system ("./spectrum_img_new 8000 " + a[0] + ".raw " + a[0] + ".bmp " + a[0] + ".txt " + sys.argv[2])


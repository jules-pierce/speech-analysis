#!/usr/bin/env python
import os
import sys

if len(sys.argv) != 2 :
    print "usage is: " + sys.argv[0] + " file.wav"
    sys.exit(0)

os.system ("sox -d -r8000 -c1 -b16 " + sys.argv[1])


